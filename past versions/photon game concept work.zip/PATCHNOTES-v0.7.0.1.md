# Patch Notes — v0.7.0.1 Hotfix (Find‑Me Again)

- **Ultra‑visible beacon:** big white cross, rotating arrow, and ping. Toggle with **V**. Still draws last, over everything.
- **Boot self‑test** returns: confirms canvas writes; shows a red warning if not.
- **On‑canvas error reporter:** any runtime error is printed on screen so we’re not debugging blind.
- Kept WASD move, mouse aim, Space/Click fire, molecules, and bond‑break emissions.
